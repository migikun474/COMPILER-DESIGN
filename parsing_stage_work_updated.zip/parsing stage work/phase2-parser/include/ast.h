#ifndef AST_H
#define AST_H

#include <memory>
#include <ostream>
#include <string>
#include <vector>

enum class ASTKind {
    Program,

    VarDecl, ParamDecl, FunctionDecl, FunctionDef, DeclGroup,
    StructDecl, UnionDecl, ClassDecl, EnumDecl, Enumerator, TypedefDecl,
    ConstructorDef, DestructorDef, InitDeclarator, InitializerList,

    CompoundStmt, IfStmt, WhileStmt, DoWhileStmt, UntilStmt, ForStmt,
    SwitchStmt, CaseStmt, DefaultStmt, LabeledStmt,
    BreakStmt, ContinueStmt, ReturnStmt, GotoStmt, ExprStmt, EmptyStmt,

    BinaryExpr, UnaryExpr, PostfixOpExpr, AssignExpr, TernaryExpr,
    CallExpr, BuiltinCallExpr, MemberExpr, ArrowExpr, ScopeExpr, IndexExpr,
    CastExpr, SizeofExpr, NewExpr, DeleteExpr, LambdaExpr, CommaExpr,

    IntLiteral, FloatLiteral, CharLiteral, StringLiteral, BoolLiteral,
    Identifier, ThisExpr, TypeNameNode,

    ErrorNode 
};

struct ASTNode {
    ASTKind kind;
    std::string label;
    int line = 0;
    std::vector<std::shared_ptr<ASTNode>> children;
};
using ASTNodePtr = std::shared_ptr<ASTNode>;

ASTNodePtr mkNode(ASTKind kind, const std::string &label = "");
ASTNodePtr mkNode(ASTKind kind, const std::string &label, std::initializer_list<ASTNodePtr> kids);
void addChild(const ASTNodePtr &parent, const ASTNodePtr &child);

const char *astKindName(ASTKind k);

void printAST(const ASTNodePtr &root, std::ostream &out);

#endif
