#ifndef TOKEN_CONVERTER_HPP
#define TOKEN_CONVERTER_HPP

#include "token_type.hpp"
int to_bison_token(TokenType t);

#endif
