#include "common.h"

#include <algorithm>
#include <cctype>

std::vector<TokenRecord> g_tokens;
std::vector<Diagnostic> g_diagnostics;
std::unordered_set<std::string> g_typedefNames;
std::vector<SymbolTableEntry> g_symbolTable;
ASTNodePtr g_astRoot;

int g_currentLine = 1;
int g_currentColumn = 1;
std::string g_lastText;
std::vector<std::string> g_sourceLines;

static std::vector<std::unordered_map<std::string, std::vector<Symbol>>> g_scopes;
static std::vector<std::string> g_scopeLabels; /* parallel to g_scopes */
static std::string g_pendingScopeLabel;
static std::string g_currentClassName;
static std::string g_currentAggregateKind;
static int g_aggregateMemberDepth = -1;

int addTokenRecord(const std::string &lexeme, const std::string &category) {
    g_tokens.push_back({lexeme, category, g_currentLine});
    return static_cast<int>(g_tokens.size()) - 1;
}

void setCategory(int idx, const std::string &category) {
    if (idx >= 0 && idx < static_cast<int>(g_tokens.size())) {
        g_tokens[idx].category = category;
    }
}

void reportDiagnostic(int line, int column, const std::string &near_text,
                       const std::string &message, const std::string &kind) {
    g_diagnostics.push_back({line, column, near_text, message, kind});
}

bool hasErrors() { return !g_diagnostics.empty(); }

std::string lastErrorLabel() {
    if (g_diagnostics.empty()) return "";
    const auto &d = g_diagnostics.back();
    return "line " + std::to_string(d.line) + ": near '" + d.near_text + "'";
}

void pushScope(const std::string &label) {
    g_scopes.emplace_back();
    std::string useLabel = label;
    if (useLabel.empty()) {
        if (!g_pendingScopeLabel.empty()) {
            useLabel = g_pendingScopeLabel;
            g_pendingScopeLabel.clear();
        } else {
            useLabel = "block";
        }
    }
    g_scopeLabels.push_back(useLabel);
}

void popScope() {
    if (!g_scopes.empty()) g_scopes.pop_back();
    if (!g_scopeLabels.empty()) g_scopeLabels.pop_back();
}

void hintScope(const std::string &label) { g_pendingScopeLabel = label; }

std::string currentScopePath() {
    std::string path;
    for (size_t i = 0; i < g_scopeLabels.size(); ++i) {
        if (i) path += " > ";
        path += g_scopeLabels[i];
    }
    return path;
}

static std::string functionPrefixOf(const std::string &path) {
    size_t pos = path.find("()");
    if (pos == std::string::npos) return path;
    return path.substr(0, pos + 2);
}

struct PendingReference {
    int tokenIdx;
    std::string name;
    std::string enclosingFunctionPrefix;
    bool isLabel;
};
static std::vector<PendingReference> g_pendingReferences;

void queuePendingReference(int tokenIdx, const std::string &name, bool isLabel) {
    g_pendingReferences.push_back({tokenIdx, name, functionPrefixOf(currentScopePath()), isLabel});
}

void resolvePendingReferences() {
    for (const auto &ref : g_pendingReferences) {
        for (const auto &e : g_symbolTable) {
            if (e.name != ref.name) continue;
            if (ref.isLabel) {
                if (e.kind != SymKind::LABEL) continue;
                if (functionPrefixOf(e.scopePath) != ref.enclosingFunctionPrefix) continue;
                setCategory(ref.tokenIdx, "LABEL");
            } else {
                if (e.scopePath != "global") continue; /* only global declarations are
                                                            legitimately forward-referenceable */
                setCategory(ref.tokenIdx, e.typeStr);
            }
            break;
        }
    }
}

const SymbolTableEntry *findMember(const std::string &tagName, const std::string &memberName) {
    if (tagName.empty()) return nullptr;
    std::string wanted = tagName + "::" + memberName;
    for (const auto &e : g_symbolTable) {
        if (e.qualifiedName == wanted) return &e;
    }
    return nullptr;
}

void enterClass(const std::string &className, const std::string &kind) {
    g_currentClassName = className;
    g_currentAggregateKind = kind;
}
void leaveClass() {
    g_currentClassName.clear();
    g_currentAggregateKind.clear();
    g_aggregateMemberDepth = -1;
}
std::string currentClassName() { return g_currentClassName; }
std::string currentAggregateKind() { return g_currentAggregateKind; }
void markAggregateMemberDepth() { g_aggregateMemberDepth = static_cast<int>(g_scopes.size()); }

void declareSymbol(const std::string &name, SymKind kind, const std::string &typeStr,
                    const SymbolDeclInfo &extra) {
    if (g_scopes.empty()) g_scopes.emplace_back(); /* safety net: global scope */

    SymbolTableEntry e;
    e.name = name;
    e.qualifiedName = g_currentClassName.empty() ? name : (g_currentClassName + "::" + name);
    e.kind = kind;
    e.typeStr = typeStr;
    e.mangledName = extra.mangledName;
    e.scopeDepth = static_cast<int>(g_scopes.size());
    e.scopePath = currentScopePath();
    e.ownerAggregateKind = (static_cast<int>(g_scopes.size()) == g_aggregateMemberDepth)
                                ? currentAggregateKind()
                                : "";
    e.declLine = (extra.tokenIdx >= 0 && extra.tokenIdx < static_cast<int>(g_tokens.size()))
                     ? g_tokens[extra.tokenIdx].line
                     : g_currentLine;
    e.isStatic = extra.isStatic;
    e.isConst = extra.isConst;
    e.isVolatile = extra.isVolatile;
    e.pointerLevel = extra.pointerLevel;
    e.arrayLevel = extra.arrayLevel;
    e.returnType = extra.returnType;
    e.paramTypes = extra.paramTypes;
    e.useCount = 0;
    g_symbolTable.push_back(std::move(e));

    int flatIndex = static_cast<int>(g_symbolTable.size()) - 1;
    g_scopes.back()[name].push_back(Symbol{kind, typeStr, extra.mangledName, extra.aggregateTagName, flatIndex});
}

const Symbol *lookupSymbol(const std::string &name) {
    for (auto it = g_scopes.rbegin(); it != g_scopes.rend(); ++it) {
        auto found = it->find(name);
        if (found != it->end() && !found->second.empty()) return &found->second.back();
    }
    return nullptr;
}

bool isOverloaded(const std::string &name) {
    for (auto it = g_scopes.rbegin(); it != g_scopes.rend(); ++it) {
        auto found = it->find(name);
        if (found == it->end()) continue;
        int count = 0;
        for (const auto &sym : found->second) {
            if (sym.kind == SymKind::PROCEDURE) ++count;
        }
        return count > 1; /* shadowing: only the innermost scope where this
                              name exists at all is what matters */
    }
    return false;
}

std::string inferExprType(const ASTNodePtr &node) {
    if (!node) return "";
    switch (node->kind) {
        case ASTKind::IntLiteral: return "INT";
        case ASTKind::FloatLiteral: return "FLOAT";
        case ASTKind::CharLiteral: return "CHAR";
        case ASTKind::StringLiteral: return "CHAR_POINTER";
        case ASTKind::BoolLiteral: return "BOOL";
        case ASTKind::Identifier: {
            const Symbol *s = lookupSymbol(node->label);
            return s ? s->typeStr : "";
        }
        default: return ""; 
    }
}

const Symbol *lookupOverload(const std::string &name, const std::vector<std::string> &argTypes) {
    for (auto it = g_scopes.rbegin(); it != g_scopes.rend(); ++it) {
        auto found = it->find(name);
        if (found == it->end() || found->second.empty()) continue;

        for (const auto &sym : found->second) {
            if (sym.kind != SymKind::PROCEDURE) continue;
            if (sym.flatIndex < 0 || sym.flatIndex >= static_cast<int>(g_symbolTable.size())) continue;
            const auto &entry = g_symbolTable[sym.flatIndex];
            if (entry.paramTypes.size() != argTypes.size()) continue;
            bool match = true;
            for (size_t i = 0; i < argTypes.size(); ++i) {
                if (entry.paramTypes[i] != argTypes[i]) { match = false; break; }
            }
            if (match) return &sym;
        }
        return &found->second.back(); 
    }
    return nullptr;
}

void recordUsage(const std::string &name) {
    recordUsage(lookupSymbol(name));
}

void recordUsage(const Symbol *s) {
    if (s && s->flatIndex >= 0 && s->flatIndex < static_cast<int>(g_symbolTable.size())) {
        g_symbolTable[s->flatIndex].useCount++;
    }
}

std::string computeTypeStr(const TypeSpec &ts, int pointerLevel, int arrayLevel) {
    std::string base;
    if (ts.parts.empty()) {
        base = "INT"; /* implicit-int, mirrors classic C default */
    } else {
        for (size_t i = 0; i < ts.parts.size(); ++i) {
            if (i) base += "_";
            base += ts.parts[i];
        }
    }
   
    for (int i = 0; i < pointerLevel; ++i) base += "_POINTER";
    /* likewise one "_ARRAY" per dimension, so int[3] and int[2][2] are
       distinguishable. */
    for (int i = 0; i < arrayLevel; ++i) base += "_ARRAY";
    return base;
}

std::string categoryForTypeName(const Symbol *s) {
    if (!s) return "TYPEDEF";
    switch (s->kind) {
        case SymKind::TYPEDEF_NAME: return "TYPEDEF";
        default: return s->typeStr; /* CLASS / STRUCT / UNION / ENUM tags */
    }
}

std::string symKindName(SymKind k) {
    switch (k) {
        case SymKind::VARIABLE: return "variable";
        case SymKind::PROCEDURE: return "procedure";
        case SymKind::PARAMETER: return "parameter";
        case SymKind::STRUCT_TAG: return "struct_tag";
        case SymKind::UNION_TAG: return "union_tag";
        case SymKind::ENUM_TAG: return "enum_tag";
        case SymKind::CLASS_TAG: return "class_tag";
        case SymKind::TYPEDEF_NAME: return "typedef";
        case SymKind::ENUM_CONST: return "enum_constant";
        case SymKind::LABEL: return "label";
    }
    return "?";
}
static std::string mangleOneType(const std::string &t) {
    std::string base = t;
    int ptr = 0, arr = 0;
    while (true) {
        if (base.size() > 8 && base.compare(base.size() - 8, 8, "_POINTER") == 0) {
            ptr++; base.resize(base.size() - 8); continue;
        }
        if (base.size() > 6 && base.compare(base.size() - 6, 6, "_ARRAY") == 0) {
            arr++; base.resize(base.size() - 6); continue;
        }
        break;
    }

    std::string code;
    if (base == "INT") code = "i";
    else if (base == "CHAR") code = "c";
    else if (base == "FLOAT") code = "f";
    else if (base == "DOUBLE") code = "d";
    else if (base == "BOOL") code = "b";
    else if (base == "VOID") code = "v";
    else if (base == "SHORT") code = "s";
    else if (base == "LONG") code = "l";
    else if (base == "STRUCT") code = "3Str";
    else if (base == "CLASS") code = "3Cls";
    else if (base == "UNION") code = "3Uni";
    else if (base == "ENUM") code = "3Enu";
    else code = std::to_string(base.size()) + base; /* fallback: length-prefixed raw name */

    for (int i = 0; i < arr; ++i) code = "A" + code;
    for (int i = 0; i < ptr; ++i) code = "P" + code;
    return code;
}

std::string mangle(const std::string &name, const std::vector<std::string> &paramTypes,
                    const std::string &className) {
    std::string out = "_Z";
    if (!className.empty()) {
        out += "N" + std::to_string(className.size()) + className;
        out += std::to_string(name.size()) + name;
        out += "E";
    } else {
        out += std::to_string(name.size()) + name;
    }
    if (paramTypes.empty()) {
        out += "v";
    } else {
        for (auto &t : paramTypes) out += mangleOneType(t);
    }
    return out;
}

ASTNodePtr registerDeclarator(DeclInfo &d, TypeSpec &ts) {
    if (d.nameIdx < 0) return nullptr; /* abstract declarator, nothing to register */

    if (ts.isTypedefStorage) {
        std::string typeStr = computeTypeStr(ts, d.pointerLevel, d.arrayLevel);
        SymbolDeclInfo extra;
        extra.tokenIdx = d.nameIdx;
        extra.pointerLevel = d.pointerLevel;
        extra.arrayLevel = d.arrayLevel;
        declareSymbol(d.name, SymKind::TYPEDEF_NAME, typeStr, extra);
        g_typedefNames.insert(d.name);
        setCategory(d.nameIdx, "TYPEDEF");
        return mkNode(ASTKind::TypedefDecl, d.name + " = " + typeStr);
    } else if (d.isFunctionPointer) {
    
        std::vector<std::string> paramTypes;
        for (auto &p : d.params) paramTypes.push_back(p.typeStr);
        std::string returnType = computeTypeStr(ts, d.pointerLevel - 1, 0);
        std::string typeStr = returnType + "_FUNCTION_POINTER";

        SymbolDeclInfo extra;
        extra.tokenIdx = d.nameIdx;
        extra.isStatic = ts.isStatic;
        extra.isConst = ts.isConst;
        extra.isVolatile = ts.isVolatile;
        extra.pointerLevel = d.pointerLevel;
        extra.returnType = returnType;
        extra.paramTypes = paramTypes;
        declareSymbol(d.name, SymKind::VARIABLE, typeStr, extra);
        setCategory(d.nameIdx, typeStr);
        return mkNode(ASTKind::VarDecl, d.name + " : " + typeStr);
    } else if (d.isFunction) {
        std::vector<std::string> paramTypes;
        for (auto &p : d.params) paramTypes.push_back(p.typeStr);
        std::string mangled = mangle(d.name, paramTypes, currentClassName());
        std::string returnType = computeTypeStr(ts, d.pointerLevel, d.arrayLevel);

        SymbolDeclInfo extra;
        extra.tokenIdx = d.nameIdx;
        extra.isStatic = ts.isStatic;
        extra.isConst = ts.isConst;
        extra.isVolatile = ts.isVolatile;
        extra.pointerLevel = d.pointerLevel;
        extra.arrayLevel = d.arrayLevel;
        extra.returnType = returnType;
        extra.paramTypes = paramTypes;
        extra.mangledName = mangled;
        declareSymbol(d.name, SymKind::PROCEDURE, "PROCEDURE", extra);
        setCategory(d.nameIdx, "PROCEDURE");

        auto node = mkNode(ASTKind::FunctionDecl, d.name + " : " + mangled);
        for (auto &p : d.params) {
            if (!p.name.empty()) addChild(node, mkNode(ASTKind::ParamDecl, p.name + " : " + p.typeStr));
        }
        return node;
    } else {
        std::string typeStr = computeTypeStr(ts, d.pointerLevel, d.arrayLevel);
        SymbolDeclInfo extra;
        extra.tokenIdx = d.nameIdx;
        extra.isStatic = ts.isStatic;
        extra.isConst = ts.isConst;
        extra.isVolatile = ts.isVolatile;
        extra.pointerLevel = d.pointerLevel;
        extra.arrayLevel = d.arrayLevel;
        extra.aggregateTagName = ts.tagName; /* enables p.x / p->x resolution below */
        declareSymbol(d.name, SymKind::VARIABLE, typeStr, extra);
        setCategory(d.nameIdx, typeStr);
        auto node = mkNode(ASTKind::VarDecl, d.name + " : " + typeStr);
        if (d.initExpr) addChild(node, d.initExpr);
        return node;
    }
}
