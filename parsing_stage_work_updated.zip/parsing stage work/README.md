# Compiler Project

A compiler for a C-like source language, built in phases — each phase
a self-contained, independently buildable and testable deliverable.

| | |
|---|---|
| Source language   | C-like language, with several C++-style extensions (see feature tables below) |
| Intermediate rep. | Three Address Code (planned, Phase 3) |
| Target language   | MIPS (planned, Phase 4) |
| Implementation    | C++17, Flex, Bison |

## Pipeline

```mermaid
flowchart LR
    SRC["Source file<br/>(.c)"] --> P1
    SRC --> P2

    subgraph P1["Phase 1 — Lexical Analyzer"]
        direction TB
        L1["flex scanner<br/>(lexer.l)"] --> L2["Lexeme / Token<br/>table"]
    end

    subgraph P2["Phase 2 — Syntax Analyzer"]
        direction TB
        S1["flex scanner<br/>(scanner.l)"] -->|"one token<br/>at a time"| S2["bison parser<br/>(parser.y)<br/>LALR(1)"]
        S2 --> S3["Token /<br/>Token_Type<br/>table"]
        S2 --> S4["Abstract<br/>Syntax Tree"]
        S2 --> S5["Symbol Table<br/>+ mangling"]
        S2 -.->|"on failure"| S6["Diagnostics<br/>+ partial AST"]
    end

    S4 --> P3["Phase 3 — TAC generation<br/>(not started)"]
    S5 --> P3
    P3 --> P4["Phase 4 — MIPS codegen<br/>(not started)"]

    style P3 stroke-dasharray: 5 5
    style P4 stroke-dasharray: 5 5
```

Phase 1 is a standalone, single-shot tool: it drains the whole file in
one `yylex()` call and prints everything it saw. Phase 2 is a real
driven parser: Bison calls `yylex()` once per token, on demand, and the
Token/AST/Symbol-table construction all happen as a byproduct of the
same LALR(1) shift-reduce parse — not a separate pass. See
[`phase2-parser/README.md`](phase2-parser/README.md) for exactly why
that difference means phase1's scanner can't just be reused to drive
phase2's parser, even though they classify the same vocabulary.

## Layout

```mermaid
flowchart TB
    ROOT["COMPILER-DESIGN-lexer-work/"]
    ROOT --> SHARED["shared/<br/><i>keyword/operator vocabulary</i>"]
    ROOT --> P1D["phase1-lexer/<br/><i>done</i>"]
    ROOT --> P2D["phase2-parser/<br/><i>done</i>"]
    ROOT --> P3D["phase3-ir/<br/><i>not started</i>"]
    ROOT --> P4D["phase4-codegen/<br/><i>not started</i>"]
    ROOT --> DOCS["docs/<br/><i>project spec</i>"]

    P1D -.->|links against| SHARED
    P2D -.->|links against| SHARED

    style P3D stroke-dasharray: 5 5
    style P4D stroke-dasharray: 5 5
```

Each phase directory holds its own `src/` (source), `test/` (test
cases), `makefile` (build recipe), and `run.sh` (runs the built
executable over every test case). Build a phase with `make` inside its
directory, then `./run.sh` to run all tests, or
`./run.sh /path/to/other/executable` to run a specific binary.

## Shared vocabulary (`shared/`)

`shared/include/token_type.hpp` and `shared/src/token_type.cpp` are the
single source of truth for "what are this language's keywords and
operators, and what do we call each one" (`TokenType` enum,
`keyword_map`, `operator_map`, `to_string()`). Both phase1-lexer and
phase2-parser link against the exact same compiled object, rather than
each maintaining their own copy — which they briefly did, and which
let their operator-naming conventions silently drift apart (phase2 was
printing raw `{`/`(` instead of `open_brace_op`/`open_paren_op` until
this was unified). Phase2 additionally has
`phase2-parser/include/token_converter.hpp`, a small adapter mapping
`TokenType` to Bison's own generated token codes — the one piece that
genuinely can't be shared, since it depends on that phase's specific
grammar.

## Quick start

| Phase | Build | Run all tests | Run one file |
|---|---|---|---|
| 1 — Lexer | `cd phase1-lexer && make` | `./run.sh` | `./lexer test/test1_arithmetic_logical.c` |
| 2 — Parser | `cd phase2-parser && make` | `./run.sh` | `./syntax_analyzer test/test1_variables_vs_procedures.c` |

## Phase 1 — Lexical Analyzer

Tokenizes the source language into lexemes using flex. On clean input it
prints a Lexeme/Token table; on invalid input it reports every lexical
error found (line number + description) instead.

See [`phase1-lexer/README.md`](phase1-lexer/README.md) for the full
token/keyword reference and [`docs/project_description.md`](docs/project_description.md)
for the full feature/design-decision history.

## Phase 2 — Syntax Analyzer

A Bison/Flex LALR(1) parser that consumes the source directly (scanning
and parsing in one pass, no pre-tokenized vector). On a valid program
it produces **three** outputs from the same parse:

1. A **Token / Token_Type** table where every identifier's Token_Type
   is *resolved from context* — `int a;` prints `a -> INT`, while
   `int a(int b, int c)` prints `a -> PROCEDURE`, `p.x` (a struct
   member) prints `x -> INT`, an overloaded call resolves to the
   *specific* overload it matches — via a scoped symbol table built up
   during parsing.
2. A real **Abstract Syntax Tree**.
3. A **Symbol Table** with C++-Itanium-*inspired* name mangling,
   readable scope ownership paths (`global > main() > if`), and usage
   counts.

On an invalid program it reports every syntax error it can (not just
the first) via panic-mode recovery, with GCC/Clang-style source
snippets, carets, and fix-it hints where the fix is unambiguous — and
still produces a **partial** AST, with an `ErrorNode` marking exactly
where each broken construct sits, instead of a silent hole.

See [`phase2-parser/README.md`](phase2-parser/README.md) for the full
write-up of the approach, and
[`phase2-parser/docs/GRAMMAR_DESIGN.md`](phase2-parser/docs/GRAMMAR_DESIGN.md)
for a production-by-production walkthrough of the grammar itself.

## Feature coverage

### Basic features (project spec)

| Feature | Status |
|---|---|
| All arithmetic/logical operators | done |
| if-else | done |
| for / while / do-while loops | done |
| switch-case | done |
| int/char arrays (incl. multi-dimensional) | done |
| Pointers (incl. multi-level) | done |
| Structures | done |
| printf / scanf | done |
| Function calls with arguments | done |
| goto / break / continue | done |
| static keyword | done |

### Advanced features (project spec)

| Feature | Status |
|---|---|
| Variable-argument function calls | done |
| Dynamic memory allocation (`malloc`/`free`/`calloc`/`realloc`) | done |
| Command-line input (`int main(int argc, char **argv)`) | done |
| typedef | done |
| Reference (`&`) | done |
| `until` loop | done |
| Multi-level pointers | done |
| Multi-dimensional arrays | done |

### Beyond the original spec — language features

Requested and implemented after the initial spec — see
[`docs/project_description.md`](docs/project_description.md#features-added-beyond-the-original-spec)
for the full writeup of each.

| Feature | Notes |
|---|---|
| `enum`, `union` | Same treatment as `struct` |
| Boolean literals & type | `true`/`false`, `bool` |
| `const` / `volatile` qualifiers | Tracked, shown in the symbol table |
| File manipulation | `FILE`, `fopen`, `fclose`, `fread`, `fwrite`, `fprintf`, `fscanf`, `fgets`, `fputs`, `feof` — all reserved keywords |
| Object-oriented features | `class`, inheritance, constructors/destructors, access modifiers, `this`, `::` |
| Lambda functions | C++-style `[capture](params) { body }` |
| `sizeof` / `new` / `delete` | Real operators, not hacked through generic calls |
| Numeric literal completeness | Binary (`0b1101`), octal with digit validation, combinable integer suffixes, leading/trailing-dot floats |

### Beyond the original spec — analysis capabilities (Phase 2 only)

None of these are semantic checks (no type errors, no redefinition
errors, no "undeclared identifier" errors are ever raised) — they're
structural classification, built on top of the syntax tree.

| Capability | What it does |
|---|---|
| Abstract Syntax Tree | One generic node shape, built as a byproduct of parsing, printed with ASCII branch art |
| Symbol table with mangling | Itanium-ABI-*inspired* mangled names (`_Z3addii`), distinguishing overloads |
| Scope ownership paths | `global > main() > if`, not a bare nesting-depth number |
| Struct vs. class vs. union member classification | `struct_member`/`class_member`/`union_member`, not a generic `variable` |
| Struct/class member access resolution | `p.x` and `pp->x` resolve `x`'s real type when `p`'s type is known |
| Forward-reference resolution | A `goto` to a later label, or a call to a function defined further down the file, resolves correctly via a deferred second pass |
| Function overload resolution | Distinguishes overloads by argument count *and* type, not just "last declared wins" |
| Lambda capture resolution | `[x, &y]` classifies `x`/`y` the same way any other identifier use does |
| Usage counting | How many times each symbol is referenced after declaration |
| GCC/Clang-style diagnostics | Source snippet, caret, column-accurate location, fix-it hints |
| Resilient partial AST | `ErrorNode` markers keep the tree complete around a syntax error instead of leaving a hole |

This language also deliberately diverges from real C in several places
(custom reserved keywords, stricter char literals, and more) — see
[Deviations from Real C (and Why)](phase1-lexer/README.md#deviations-from-real-c-and-why)
for the full list with justifications.
